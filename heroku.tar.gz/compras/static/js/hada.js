// var nombre_boton_agregar = ".hadas"; // Clase

//     $(document).on('ready',function(){
//         $(nombre_boton_agregar).on('click',function(e){
//             e.preventDefault();
//             var Pid = $(this).attr('id');
//             $('#modal_idProducto2').val(Pid);
//         });
//         //     var options = {
//         //         success:function(response)
//         //         {
//         //             if(response.statusa=="True"){
//         //                 alert("agregado!");
//         //                 var idProd = response.product_id2;

//         //                     $('#tr'+idProd).append();                     
                        
//         //             }else{
//         //                 alert("Hubo un error al agregar!");
//         //             };
//         //         }
//         //     };

//         // $(nombre_formulario_modal2).ajaxForm(options);

//     });
    

