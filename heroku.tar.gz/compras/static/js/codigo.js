// $(document).ready(inicio)

// function inicio(){
// 	$(".carrito").click(anade)
// }
// function anade(){
// 	$("#cuerpo_carrito").append($(this).val());
// }