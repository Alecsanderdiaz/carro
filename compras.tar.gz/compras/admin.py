from django.contrib import admin

# Register your models here.

from compras.models import Producto

admin.site.register(Producto)